extends Node3D
## Minimal procedural mountain / visual starter scene.
## Gameplay systems intentionally belong to later implementation milestones.

const TERRAIN_WIDTH := 220.0
const TERRAIN_LENGTH := 800.0
const GRID_STEP := 8.0

var preview_camera: Camera3D

func _ready() -> void:
	_create_environment()
	_create_mountain()
	_create_summit_marker()
	_create_camera()


func _height(x: float, z: float) -> float:
	# Heading downhill toward +Z; deterministic terrain for repeatable time trials.
	return 145.0 - 0.18 * z + 3.0 * sin(x / 21.0) * sin(z / 32.0) + 1.5 * sin(z / 13.0)


func _create_environment() -> void:
	var sky_env := Environment.new()
	sky_env.background_mode = Environment.BG_COLOR
	sky_env.background_color = Color(0.57, 0.69, 0.79)
	sky_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	sky_env.ambient_light_color = Color(0.86, 0.9, 0.98)
	sky_env.ambient_light_energy = 0.7
	var world_env := WorldEnvironment.new()
	world_env.environment = sky_env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-46.0, -28.0, 0.0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)


func _create_mountain() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var x_steps := int(TERRAIN_WIDTH / GRID_STEP)
	var z_steps := int(TERRAIN_LENGTH / GRID_STEP)
	for iz in range(z_steps):
		for ix in range(x_steps):
			var x := -TERRAIN_WIDTH * 0.5 + float(ix) * GRID_STEP
			var z := float(iz) * GRID_STEP
			var a := Vector3(x, _height(x, z), z)
			var b := Vector3(x + GRID_STEP, _height(x + GRID_STEP, z), z)
			var c := Vector3(x, _height(x, z + GRID_STEP), z + GRID_STEP)
			var d := Vector3(x + GRID_STEP, _height(x + GRID_STEP, z + GRID_STEP), z + GRID_STEP)
			# Winding produces upward-facing surface normals.
			st.add_vertex(a)
			st.add_vertex(c)
			st.add_vertex(b)
			st.add_vertex(b)
			st.add_vertex(c)
			st.add_vertex(d)
	st.generate_normals()
	var snow_mesh := st.commit()
	var snow_mat := StandardMaterial3D.new()
	snow_mat.albedo_color = Color(0.91, 0.95, 0.98)
	snow_mat.roughness = 0.87
	var surface := MeshInstance3D.new()
	surface.name = "SnowSurface"
	surface.mesh = snow_mesh
	surface.material_override = snow_mat
	add_child(surface)

	var terrain_body := StaticBody3D.new()
	terrain_body.name = "SnowCollision"
	var terrain_collision := CollisionShape3D.new()
	terrain_collision.shape = snow_mesh.create_trimesh_shape()
	terrain_body.add_child(terrain_collision)
	add_child(terrain_body)


func _create_summit_marker() -> void:
	# A simple board-shaped visual at the starting summit, NOT a rider controller yet.
	var marker := MeshInstance3D.new()
	marker.name = "BoardPlaceholder"
	var shape := BoxMesh.new()
	shape.size = Vector3(0.33, 0.07, 1.75)
	marker.mesh = shape
	marker.position = Vector3(0.0, _height(0.0, 8.0) + 0.16, 8.0)
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.11, 0.14, 0.19)
	marker.material_override = material
	add_child(marker)


func _create_camera() -> void:
	preview_camera = Camera3D.new()
	preview_camera.name = "PreviewCamera"
	preview_camera.current = true
	preview_camera.fov = 75.0
	preview_camera.position = Vector3(0.0, _height(0.0, -12.0) + 6.0, -12.0)
	add_child(preview_camera)
	preview_camera.look_at(Vector3(0.0, _height(0.0, 55.0) + 2.0, 55.0), Vector3.UP)
