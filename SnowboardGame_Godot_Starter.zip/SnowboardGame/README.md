# SnowboardGame (working title)

A Godot 4 project for a cinematic, HUD-free snowboard time trial down one massive mountain.

## Intended Windows location

`D:\SnowboardGame` (that is, a project folder **directly on D:**, not under Documents, Desktop, or another project folder).

The Godot project file is `D:\SnowboardGame\project.godot`.

## Getting started

1. Extract the provided ZIP to `D:\` so that its top-level folder becomes `D:\SnowboardGame`.
2. Open **Godot 4.x**. In Project Manager, choose **Import**, then select `D:\SnowboardGame\project.godot`.
3. Press **F5** or use the Run Project button.
4. The initial scene is deliberately a **visual scaffold only**: a procedurally generated snowy descent, a snowboard placeholder, and a camera. It does **not yet** implement riding, tricks, nitro, crashes, audio, timer, leaderboard, or controller mapping.

This scaffold is provided so Claude can begin from an actual, importable Godot project rather than an empty concept description. Godot was not available in the packaging environment, so opening/importing this project in Godot on Windows is the first validation step.

## Handing this project to Claude

Read `CLAUDE.md` first. It contains the authoritative project instructions and locked gameplay decisions. `docs/GAME_DESIGN.md` records behavior, and `docs/IMPLEMENTATION_PLAN.md` organizes the build steps.

**Claude Code (preferred):** Open a terminal in `D:\SnowboardGame`, then run `claude`. Claude Code will discover `CLAUDE.md` in the project root. Paste the first-task prompt from `docs/CLAUDE_START_PROMPT.txt`.

**Claude chat/browser:** Share the project folder via a ZIP or repository, and attach/include `CLAUDE.md`, `docs/GAME_DESIGN.md`, and `docs/IMPLEMENTATION_PLAN.md` with the request. Claude chat cannot edit your local D: drive unless you also give it an appropriate connected workspace or local coding tool.

## Version control

In PowerShell from the project directory:

```powershell
Set-Location 'D:\SnowboardGame'
git init
git add .
git commit -m 'Initial Godot snowboard scaffold and design documentation'
```

Use a private GitHub repository to share the full history with collaborators if desired. Do not commit Godot cache `.godot/`, secrets, or copyrighted music/audio you cannot redistribute.

## Scope boundary

Do not add helicopters or wildlife in the first build. Do not add a health/injury system. Gameplay remains HUD-free; only the pause menu exposes the run timer, top 10 finishes, and controller mapping.

### One-command extraction (PowerShell)

After downloading the ZIP to your Downloads folder, run:

```powershell
Expand-Archive -LiteralPath "$env:USERPROFILE\Downloads\SnowboardGame_Godot_Starter.zip" -DestinationPath "D:\" -Force
```

Do not run this over a project you have already edited: `-Force` can overwrite scaffold files.
