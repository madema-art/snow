# Implementation Plan (Godot 4)

## M0: Project scaffold (packaged)

- Godot 4 project with `project.godot` and a procedural fixed snowy mountainside preview.
- Scene imports without external assets (needs verification in a local Godot installation).
- Design documentation and Claude handoff instructions in the project root.

## M1: Rideable short vertical slice

- Replace placeholder board with rider character, board visual, gravity-based downhill locomotion, carving, braking, tuck, jump/landing, and controller input.
- Implement camera following, terrain lookahead, FOV adjustment and clipping avoidance.
- Start stationary; input push-off starts timer. Automatic finish line at end of prototype.
- No gameplay overlays and no wildlife or helicopter.
- Add a short test descent (~60–90 seconds **as a target**, subject to measured time).

## M2: Nitro/tricks/crashes

- Introduce simple spins/grabs, trick registration and payout upon successful landing.
- Board-based nitro color and charge, spending, responsive acceleration, empty-attempt sputter.
- Collision classifications, severe vs recoverable falls, zero speed/zero nitro on any fall.
- Fatal cliff and extreme tree collisions, restart flow, no injury system.

## M3: Pause and records

- Start/Menu true pause, timer paused exactly, top-ten persistent completed times (hundredth-second precision), remappable gameplay buttons (left-stick steering and Start/Menu reserved).
- Controller-only accessible remapping with persistent storage and conflict handling.
- Pause UI only; keep active game HUD-free.

## M4: Sound pass

- Adaptive mix for board on different snow types, carving, wind speed, air gaps, landings, crashes, nitro and empty sputter.
- Designed impact samples; 3D positioning for terrain hazards; controller vibration.
- Music hookup isolated for later user-provided music.

## M5: Full mountain and optimization

- Expand from vertical slice to one fixed mountain with hazards, high-risk shortcuts and distinct terrain regions.
- Aim at ~5:00 good complete descent and faster expert runs; measure actual run times.
- Optimize terrain meshes/collision/LOD/culling, avoid stutters during speed boosts.
- Harden deterministic conditions, finish qualification, personal bests and testing.

## Baseline QA gate for every milestone

- Godot imports the project with **no script parse errors**.
- Game runs with Xbox controller and does not require keyboard to play.
- No HUD during active gameplay.
- Time does not advance before push-off, while paused, or after finish.
- Any fall wipes **both** forward speed and nitro; no injury stats.
- Completing, restarting, exiting and relaunching do not corrupt records/remaps.
- Startup/restart is quick and reliable.
