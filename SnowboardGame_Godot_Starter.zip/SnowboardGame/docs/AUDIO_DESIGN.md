# Audio Direction (first build)

**Goal:** tactile, cinematic, unusually impactful, and responsive. Audio should convey board state, speed, snow contact and risk without a HUD.

## Layers / events

| Event / state | Design direction | Reacts to |
|---|---|---|
| Snow gliding | Fine-grain hiss, edge scrape, deep packed-snow contact | Speed, snow type, board load |
| Carve | Aggressive, directional cutting sound and snow spray | Edge angle and lateral force |
| Ice | Sharp, irregular high-frequency chatter | Surface and vibration |
| Wind | Low/mid airy roar, close whistling at high speeds | Speed, gusts, camera orientation |
| Takeoff | Snow scrape abruptly falls away; open-air whoosh remains | Ground-contact transition |
| Landing | Weighty low thud, transient crack and spray texture | Vertical impact energy, surface |
| Falls | Multiple directional impacts, gear rattle, slide | Crash severity, body velocity |
| Nitro charging | Low resonant harmonic tone, short rewarding landing ping | Trick payout, stored charge |
| Nitro activation | Unique deep 'thoom' into energized accelerating tone | Boost start/active speed |
| Nitro depletion | Downward fluttering tail | Charge crossing to zero |
| Empty attempt | Short mechanical sputter/cough; never a menu warning | Boost pressed at zero charge |
| Nitro lost on fall | Abrupt descending electrical cutoff | Crash transition |
| Fatal impact | Powerful single transient, then environmental decay | Fatal state |

## Technical recommendations

- Prefer procedural modulation/blending of layered original/cleared recordings over one generic looping sound.
- Avoid aggressive permanent music ducking. Short, tasteful ducking/sidechain for major landing/crash moments.
- Keep SFX bus and music bus separate; reserve music for tracks provided by the user.
- Provide playable prototyping sounds first, then replace with curated recordings. Document licensing/provenance.
- Support controller rumble on landings, intense edge chatter, nitro onset, and empty sputter (not constant rumble).
- Do not display audio cues or waveform meters during active play.
