# Locked Design Decisions

- Engine: **Godot 4**, Windows PC, controller first.
- Install/project root: **`D:\SnowboardGame`**, folder directly under D:.
- Game: one snowboarder, one huge fixed snowy mountain, fastest finish wins; ~5-minute good full descent is a design target.
- First build excludes **wildlife and helicopter**.
- Start stationary at summit; **push-off starts clock**.
- No HUD during gameplay. Pause menu shows **current time, top 10 finished times, controller remapping**.
- Start/Menu pause/resume reserved. Left-stick steering reserved. Every other gameplay button can be reassigned.
- Tricks recharge boost, only upon successful landing. Board color/glow indicates charge. Boost has distinctive sound and sputters when empty.
- Any fall: **all nitro removed, all forward speed removed**; recovery time scaled to crash severity.
- No injury/health system. Fatal cliff falls and extreme head-on tree impacts possible.
- Audio and physics are top quality priorities.
- No finalized project title; `SnowboardGame` is a working folder/project name only.
