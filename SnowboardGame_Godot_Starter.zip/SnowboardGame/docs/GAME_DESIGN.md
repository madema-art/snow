# Game Design Specification

## High concept

Single-player, controller-first, cinematic downhill snowboard time trial on a massive **untracked, hazardous, snow-covered mountain**. One rider, no opponents, no lifts, no HUD. The objective is to reach the valley floor as fast as possible, ideally around **5:00** for a good but improvable run; experts can learn faster lines. Full target scale and times must be tuned through playtesting, not treated as existing content.

## Starting and ending a run

- Spawn still at the summit, facing down the mountain. **No helicopter sequence.**
- Run timer begins **when the player pushes off**, not on scene load and not on camera movement.
- `A` is a proposed default push-off control and can become Jump once underway; both are remappable gameplay actions. Exact default map will be refined.
- The finish should be identifiable naturally without requiring a HUD marker.
- At the finish, stop timer; store completed run in persistent top-ten fastest leaderboard. Show current/finishing time and records in the pause/results context, never as a persistent running overlay.
- Offer near-instant replay at the summit. The run timer resets and nitro starts empty.

## Terrain

- **One fixed mountain** with multiple traversable routes, natural terrain features and recognizable landmarks.
- Rocks, trees, cliffs, ravines, crevasses, jumps, chutes, open slopes, and forested areas.
- Readable hazards: players should lose because of decisions, not invisible obstacles.
- The first milestone can use a shorter section, then expand to target the full approximately 5-minute descent.
- **No wildlife or helicopter in first build.** Advanced storms/avalanches deferred.

## Controls

- Xbox controller support, with keyboard fallback for development.
- **Left stick controls steering and cannot be remapped.**
- **Start/Menu controls pause/resume and cannot be remapped.**
- All other gameplay button assignments remappable, including relevant face buttons, bumpers, triggers, D-pad directions and stick clicks. Right-stick camera behavior can remain on the right-stick axes; any non-steering *button* action must be remappable.
- Controller mapping persisted between launches; prevent confusing conflicts or provide a clear swap interaction.
- Provisional bindings: A push-off/jump, B boost, X grab, LT brake, RT tuck, LB/RB spin left/right; not permanent.

## Boarding feel

- Credible gravity-driven acceleration and speed, edge/carving, turning radius vs speed, friction by snow type, weight/lean and landing consequences. Not uncompromising simulation; responsiveness matters.
- Steering and camera preserve readability at speed; the camera adapts FOV/distance and anticipates upcoming terrain.
- Tricks: ollies, spins, grabs and flips, including chaining combinations. Generate boost **only after clean landing**. Larger, riskier tricks generally generate more.
- Boost can be used in partial charges and should not give magic extra traction. Activation accelerates the rider and may increase crash risk.

## Nitro presentation

- No boost bar or HUD icon.
- As stored nitro increases, the board progresses from dark to warm glowing orange to bright near-white, optionally affecting bindings and reflected light.
- Boost activation: pronounced unique tone and acceleration sound. Empty boost attempt: a **brief sputter/cough**, plus tactile feedback.
- Spent energy drains glow. Any fall instantly drains **all** nitro and darkens the board.
- Advanced overcharge is an **optional future experiment**, not a v1 requirement.

## Crashes and death

- Any actual fall wipes out **all forward speed and all stored nitro immediately**. No partial retention.
- Minor crashes recover quickly; bigger crashes have longer get-up animations. Suggested *initial* targets: minor 1–2 s, moderate 3–5 s, severe 6–10 s.
- The clock keeps running during collision, ragdoll/tumble and getting up.
- Collision severity determined by context: speed, angle, surface/object, etc.
- Trees: glancing or lower-speed collisions can cause a recoverable fall; some direct high-speed impacts are fatal. Falling over an unsurvivable cliff or into a deadly ravine is fatal.
- No injury mechanics, wound indicators, health bars or stamina system.
- Fatal attempts do not count as completed times; best records are preserved.

## Pausing and records

- Start/Menu pauses instantly, including when airborne. Pause freezes **physics, animations as appropriate, timed gameplay and timer**.
- Pause display ONLY needs the **current run time**, **top 10 fastest completed finishes**, and **controller button assignment UI**, plus implicit resume navigation. No general options menus.
- Times recorded with at least 0.01-second display precision, stored across sessions.
- During active riding, no time, score, text warnings, boost bars, tutorial prompts, or other overlay.

## Sound and music

- Sound effects are central to game feel. Responsive snow friction/edge chatter, wind speed/gusts, clothing motion, aerial silence, landings, falls, and nitro.
- Collision audio should communicate severity and environment; 3D world sounds and appropriate spatial attenuation.
- User will make/provide music. Effects and music must have separate controls/channels internally, without exposing unwanted gameplay HUD.

## Decisions still open for playtesting

Exact mass/friction constants; snowboard physics modeling approach; mountain overall length/elevation and ideal route; specific trick input combinations; nitro gain/burn/acceleration; audio assets; official run weather behavior; exact finishing visual, result reveal, and reset control.
