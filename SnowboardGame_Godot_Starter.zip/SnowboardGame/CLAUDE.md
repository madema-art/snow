# Claude project instructions: SnowboardGame

You are collaborating on a **Godot 4** PC snowboarding game in `D:\SnowboardGame`.
This file is the canonical context handoff. **Read this file and `docs/GAME_DESIGN.md` before writing or modifying game code.**

## Project principles

1. Build **one enormous, fixed, memorable snow-covered mountain** intended to support an approximately **five-minute good-but-improvable complete descent**. For a first vertical slice, a short downhill section is acceptable; the final mountain goal must remain visible in the roadmap.
2. The player is the **only snowboarder**. First build has **no helicopter, no wildlife**. Start stationary at the summit and start the run timer **only when the player pushes off**.
3. **Absolutely no gameplay HUD**: no clocks, bars, trick scores, pop-ups, button prompts, or text during an active run. The **pause screen** may show current run time, top 10 fastest finishes, and remappable controller bindings.
4. Physics-driven feel: believable gravity, carving, braking, air control, snow friction, speed, and consequences, but not strict simulation. Tricks award **nitro/boost on successful landing**. Boost is an intentional arcade mechanic.
5. Show boost charge through **snowboard color/glow**, not a meter. Provide distinctive charging and activation sounds, plus a short sputter when boost is requested empty.
6. **Any fall immediately removes all stored nitro AND all forward travel speed.** Crashes cost recovery time; severity influences recovery duration. There is **no injury or health system**. Deadly cliff falls and extreme head-on tree collisions may end the run.
7. **Xbox-style controller support** is a priority. Left stick steering is permanently fixed; Start/Menu is permanently pause/resume. **All other gameplay buttons are remappable** and persistent. Controller-only navigation must work within the pause menu.
8. Pausing freezes simulation and the timer. The pause screen includes the **current run time**, **10 fastest completed runs**, and **controller mapping**; nothing else is required. Finish times persist between sessions.
9. Audio is a first-class system: responsive, weighty edge/carve friction, wind, jump silence, heavy landings, crash tumbles, and boost with an empty-charge sputter. The user will provide music later. Never invent or include copyrighted music tracks.
10. Design a consistent deterministic mountain/official time-trial scenario so a top-ten leaderboard compares runs fairly. Gameplay should be responsive and have fast, frictionless restarts from the summit.

## Important boundaries

- The project is **not fully implemented yet**. `scripts/main.gd` is a **visual scaffold**, not an operational snowboard game. Never describe the current state as feature-complete.
- Do not quietly substitute a different engine or scatter project files around other drives.
- No gimmicky overlays, game-over screens, trophy popups, or obligatory tutorial screens during a run.
- Do not add wildlife or a helicopter to the initial build. Advanced storm/avalanche systems can wait.
- Do not confuse physics momentum with the game mechanic named nitro/boost. On any crash, both motion speed and accumulated boost are reset.
- Favor a **single cohesive implementation task per prompt**, followed by a short report: files changed, test results, and known limitations.

## Architecture suggestions (not yet locked)

- `scenes/`: world, rider, pause menu scenes
- `scripts/`: rider physics state machine, controller input/remapping, tricks/boost, run state, records, camera, procedural/hand-built terrain, sound mixer
- `audio/`: original/approved source recordings, layers, effects
- `docs/`: decisions, build plan, audio direction, QA notes
- Make physics deterministic enough for repeatable input-based testing where practical.
- Separate visual FX from game-state rules and ensure no change to visible boost glow changes the actual stored boost.
- Persist control settings and records to `user://` paths via Godot APIs.

## Collaboration workflow

- Keep `docs/BUILD_STATUS.md` accurate after every coding task (what runs, what is stubbed, what is untested).
- Keep `docs/DECISIONS.md` updated if design changes.
- Run Godot parser/import and available automated tests before calling a change complete. If Godot is not installed, say so explicitly and never claim a validated build.
- Report Windows-specific instructions using PowerShell commands and root `D:\SnowboardGame`.
- Recommend a small Git commit after each working milestone. Do not force push or rewrite history.
- Ask about truly conflicting requirements, but otherwise choose reasonable defaults and implement them.

## Read next

1. `docs/GAME_DESIGN.md`: exact gameplay constraints
2. `docs/IMPLEMENTATION_PLAN.md`: development priorities
3. `docs/AUDIO_DESIGN.md`: sound behavior and interfaces
4. `docs/BUILD_STATUS.md`: what exists today
