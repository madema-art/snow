@echo off
setlocal
cd /d "%~dp0"
where godot >nul 2>nul
if not errorlevel 1 (
  godot --path "%CD%" --editor
  exit /b %errorlevel%
)
where godot4 >nul 2>nul
if not errorlevel 1 (
  godot4 --path "%CD%" --editor
  exit /b %errorlevel%
)
echo Godot is not on PATH. Open Godot 4 Project Manager and import:
echo %CD%\project.godot
echo.
pause
endlocal
